import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;

import java.io.*;
import java.net.*;
import java.util.concurrent.atomic.AtomicInteger;

public class LoadBalancer {

    // Backend servers
    static String[] servers = {
            "http://localhost:8081",
            "http://localhost:8082",
            "http://localhost:8083",
            // Add more if needed
             "http://localhost:8085"
    };

    // Round robin counter
    static AtomicInteger index = new AtomicInteger(0);

    public static void main(String[] args) throws Exception {

        // IMPORTANT: Bind to all IPs (for friend access)
        HttpServer server = HttpServer.create(
                new InetSocketAddress("0.0.0.0", 9090), 0);

        server.createContext("/", (HttpExchange exchange) -> {

            // Round Robin logic
            int i = index.getAndIncrement() % servers.length;
            String target = servers[i] + exchange.getRequestURI();

            System.out.println("Forwarding to: " + target);

            try {
                URL url = new URL(target);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                conn.setRequestMethod(exchange.getRequestMethod());
                conn.setDoInput(true);

// 🔥 Only for POST / PUT
                if ("POST".equals(exchange.getRequestMethod()) || "PUT".equals(exchange.getRequestMethod())) {
                    conn.setDoOutput(true);

                    InputStream is = exchange.getRequestBody();
                    OutputStream os = conn.getOutputStream();
                    is.transferTo(os);
                    os.close();
                }
                int responseCode = conn.getResponseCode();

                InputStream responseStream;
                try {
                    responseStream = conn.getInputStream();
                } catch (Exception e) {
                    responseStream = conn.getErrorStream();
                }

                byte[] response = responseStream.readAllBytes();

// 🔥 IMPORTANT FIXES
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");

// 🔥 VERY IMPORTANT (fix duplicate issue)
                exchange.sendResponseHeaders(responseCode, response.length);

                OutputStream os = exchange.getResponseBody();
                os.write(response);
                os.flush();
                os.close();

            } catch (Exception e) {
                // If server fails
                String error = "Server down: " + target;
                System.out.println(error);

                exchange.sendResponseHeaders(500, error.length());
                OutputStream os = exchange.getResponseBody();
                os.write(error.getBytes());
                os.close();
            }
        });
        server.start();
        System.out.println("Load Balancer running on port 9090...");
    }
}
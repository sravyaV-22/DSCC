let cart = JSON.parse(localStorage.getItem("cart")) || [];

let out = "";
let total = 0;

cart.forEach((c, i) => {
    total += c.price;

    out += `
    <div class="cart-item">
        <h4>${c.name}</h4>
        <p>${c.price}</p>
        <button onclick="removeItem(${i})">Remove</button>
    </div>`;
});

out += `<h3>Total: ${total}</h3>`;

document.getElementById("cart").innerHTML = out;

function removeItem(i) {
    cart.splice(i, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    location.reload();
}

function goAddress() {
    window.location = "address.html";
}
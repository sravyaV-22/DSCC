function login() {
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    fetch("http://localhost:8081/login", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({email, password})
    })
    .then(res => res.text())
    .then(data => {
        if (data === "Login Success") {
            localStorage.setItem("user", email);
            window.location = "index.html";
        } else {
            alert("Invalid login");
        }
    });
}

function register() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    console.log(name, email, password); // debug

    fetch("http://localhost:8081/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            name: name,
            email: email,
            password: password
        })
    })
    .then(res => res.text())
    .then(data => {
        alert("Registered Successfully");
        window.location.href = "login.html";
    })
    .catch(err => {
        console.log(err);
        alert("Error: Backend not running");
    });
}
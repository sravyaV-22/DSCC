function placeOrder() {

     let address = document.getElementById("address").value;
     let city = document.getElementById("city").value;
     let pincode = document.getElementById("pincode").value;

     fetch("http://localhost:9090/address", {
         method: "POST",
         headers: {"Content-Type": "application/json"},
         body: JSON.stringify({fullAddress: address, city, pincode})
     });

     fetch("http://localhost:9090/orders")
     .then(res => res.json())
     .then(data => {
         let out = "";
         data.forEach(o => {
             out += `<p>Order ₹${o.totalAmount} - ${o.status}</p>`;
         });
         document.getElementById("orders").innerHTML = out;
     });
     alert("Order placed!");
 }
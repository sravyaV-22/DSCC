let allProducts = [];

function loadProducts() {
    fetch("http://localhost:8081/products")
    .then(res => res.json())
    .then(data => {
        allProducts = data;
        display(data);
    });
}

function filter(category) {
    fetch("http://localhost:9090/products?category=" + category)
    .then(res => res.json())
    .then(data => display(data));
}

function searchProducts(text) {
    let filtered = allProducts.filter(p =>
        p.name.toLowerCase().includes(text.toLowerCase())
    );
    display(filtered);
}

function goCart() {
    window.location = "cart.html";
}

function loadProducts() {
    fetch("http://localhost:9090/products")
    .then(res => res.json())
    .then(data => display(data))
    .catch(err => console.log(err));
}

function display(products) {
    let out = "";

    products.forEach(p => {
        out += `
        <div class="card">
            <img src="https://source.unsplash.com/200x200/?${p.category}">
            <h3>${p.name}</h3>
            <p>₹${p.price}</p>
            <button onclick="addToCart('${p.name}', ${p.price})">
                Add to Cart
            </button>
        </div>`;
    });

    document.getElementById("products").innerHTML = out;
}

function addToCart(name, price) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push({name, price});
    localStorage.setItem("cart", JSON.stringify(cart));
    alert("Added to cart");
}

window.onload = loadProducts;
loadProducts();
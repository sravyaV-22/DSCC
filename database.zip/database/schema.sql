-- USERS
CREATE TABLE users (
    id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR2(100),
    email VARCHAR2(100),
    password VARCHAR2(100)
);

-- PRODUCTS
CREATE TABLE product (
    id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name VARCHAR2(100),
    price NUMBER,
    category VARCHAR2(50)
);

-- CART
CREATE TABLE cart (
    id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id NUMBER,
    product_id NUMBER,
    quantity NUMBER
);

-- ADDRESS
CREATE TABLE address (
    id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id NUMBER,
    full_address VARCHAR2(200),
    city VARCHAR2(50),
    pincode VARCHAR2(10)
);

-- ORDERS
CREATE TABLE orders (
    id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id NUMBER,
    total_amount NUMBER,
    address_id NUMBER,
    status VARCHAR2(50)
);